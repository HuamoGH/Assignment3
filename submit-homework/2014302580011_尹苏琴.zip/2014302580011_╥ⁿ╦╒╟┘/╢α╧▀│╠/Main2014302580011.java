package com.yinsuqin.homework;

import java.io.IOException;
import java.sql.*;

/**
 * Created by Administrator on 2015/11/11.
 */
public class Main2014302580011 {
    public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
        long StartTime = System.currentTimeMillis();
        Info2014302580011 Info = new Info2014302580011();
        Info.run();

        Class.forName("com.mysql.jdbc.Driver");
        //long start = System.currentTimeMillis();
        Connection connection = DriverManager.getConnection
                ("jdbc:mysql://localhost:3306/teacherinfomation", "root", "123456");

        for (int i = 0;i<Info.getName().size();i++){
            String sql = "INSERT INTO teacherinfotable(Id,Name,Email,Tel,Info) VALUES (?,?,?,?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,i+1);
            preparedStatement.setString(2,Info.getName().get(i));
            preparedStatement.setString(3,Info.getEmail().get(i));
            preparedStatement.setString(4,Info.getTelephone().get(i));
            preparedStatement.setString(5,Info.getResearch().get(i));
            preparedStatement.execute();
        }

        long EndTime = System.currentTimeMillis();

        System.out.println("多线程运行时间为： " + (EndTime-StartTime) + " 毫秒");


    }
}
