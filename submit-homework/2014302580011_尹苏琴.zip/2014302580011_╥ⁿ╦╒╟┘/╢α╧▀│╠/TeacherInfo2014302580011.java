package com.yinsuqin.homework;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;

/**
 * Created by Administrator on 2015/11/9.
 */
public class TeacherInfo2014302580011 implements Runnable {
    private String URL;
    public String Name;
    public String Email;
    private String Research;
    private String Teleohone;
    private Document doc;
    private Elements elements;

    public TeacherInfo2014302580011(String url) throws IOException {
        URL = url;
        doc = Jsoup.connect(URL).get();
        elements = doc.select("div>p");
    }

    public void getName(){
        Elements elements = doc.getElementsByClass("title");
        this.Name = elements.text().toString();
        //return this.Name;
    }

    public void getEmail() {
        String[] temp = this.elements.get(0).toString().split(" [<][b][r][>] ");
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(temp[3]);
        stringBuffer.delete(stringBuffer.length() - 5, stringBuffer.length());
        stringBuffer.delete(0, 7);
        this.Email = stringBuffer.toString();
        //return Email;
    }

    public String getResearch() {
        String[] temp = this.elements.get(0).toString().split(" [<][b][r][>] ");
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(temp[1]);
        stringBuffer.delete(0, 5);
        this.Research = stringBuffer.toString();
        return Research;
    }

    public String getTeleohone() {
        String[] temp = this.elements.get(0).toString().split(" [<][b][r][>] ");
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(temp[2]);
        stringBuffer.delete(0, 6);
        this.Teleohone = stringBuffer.toString();
        return Teleohone;
    }

    @Override
    public void run() {
        this.getName();
        this.getEmail();
    }
}
