package com.yinsuqin.homework;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Administrator on 2015/11/9.
 */
public class Info2014302580011 {
    private ArrayList<String> Name;
    private ArrayList<String> Email;
    private ArrayList<String> Research;
    private ArrayList<String> Telephone;

    public void run() throws IOException {
        ArrayList<String> Name;
        ArrayList<String> Email;
        ArrayList<String> Research;
        ArrayList<String> Telephone;
        Solution2014302580011 solution = new Solution2014302580011();
        solution.run();
        solution.correctDetail();
        this.Name = solution.getName();
        this.Email = solution.getEmail();
        this.Research = solution.getResearch();
        this.Telephone = solution.getTelephone();
    }

    public ArrayList<String> getName() {
        return Name;
    }

    public ArrayList<String> getEmail() {
        return Email;
    }

    public ArrayList<String> getResearch() {
        return Research;
    }

    public ArrayList<String> getTelephone() {
        return Telephone;
    }
}
