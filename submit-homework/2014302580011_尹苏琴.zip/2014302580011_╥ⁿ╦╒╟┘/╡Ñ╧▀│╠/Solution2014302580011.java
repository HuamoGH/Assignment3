package com.yinsuqin.homework;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Administrator on 2015/11/8.
 */
public class Solution2014302580011 {

    private ArrayList<String> Name = new ArrayList<>();
    private ArrayList<String> Email = new ArrayList<>();
    private ArrayList<String> Research = new ArrayList<>();
    private ArrayList<String> Telephone = new ArrayList<>();
    public void run() throws IOException {


        TeacherURL2014302580011 TeacherPage = new TeacherURL2014302580011();

        ArrayList<String> TeacherURL = TeacherPage.getURL();

        //for (int i = 0;i<TeacherURL.size();i++){
        //    System.out.println(TeacherURL.get(i));
        //}

        for (int i = 0; i < TeacherURL.size(); i++) {
            TeacherInfo2014302580011 TeacherInfo =
                    new TeacherInfo2014302580011(TeacherURL.get(i));

            //添加名字
            Name.add(i, TeacherInfo.getName());

            //添加邮箱
            if (TeacherInfo.getEmail().matches("\\w+@(\\w+.)+[a-z]{2,3}")) {
                Email.add(i, TeacherInfo.getEmail());
            } else {
                Email.add(i, "null");
            }

            //添加研究方向
            if (TeacherInfo.getResearch().matches
                    ("[ ]([\\u4e00-\\u9fa5])+[、]?[，]?([\\u4e00-\\u9fa5])+[、]?[，]?([\\u4e00-\\u9fa5])+[、]?[，]?([\\u4e00-\\u9fa5])+")) {
                Research.add(i, TeacherInfo.getResearch());
            } else {
                Research.add("");
            }

            //添加电话号码
            Telephone.add(i, TeacherInfo.getTeleohone());

        }

    }

    public void correctDetail() {
        //补加一些不符合格式的
        this.Research.remove(15);
        this.Research.add(15, " 高分子化学与物理");
        this.Research.remove(20);
        this.Research.add(20, " 框架化学（Reticular Chemistry）绿色能源储存");
        this.Research.remove(23);
        this.Research.add(23, " 化学 物理化学");
        this.Research.remove(34);
        this.Research.add(34, " 分析化学");
        this.Research.remove(40);
        this.Research.add(40, "理论计算机化学");
        this.Research.remove(42);
        this.Research.add(42, " 原子光谱/质谱分析");
        this.Research.remove(46);
        this.Research.add(46, " 物理化学，电化学");
        this.Research.remove(53);
        this.Research.add(53, " 有机化学");
        this.Research.remove(62);
        this.Research.add(62, " 分析化学（毛细管电泳/液相色谱分离分析）");
        this.Research.remove(70);
        this.Research.add(70, " 高分子化学与物理");
        this.Research.remove(75);
        this.Research.add(75, " 高分子化学与物理");
        this.Research.remove(77);
        this.Research.add(77, " 高分子化学");
        this.Research.remove(82);
        this.Research.add(82, " ①生物热化学与热分析；②生命动态过程化学；③靶向药物化学；④纳米生物效应；⑤小分子与生物大分子相互作用");
        this.Research.remove(83);
        this.Research.add(83, " 富勒烯与碳纳米材料");
        this.Research.remove(84);
        this.Research.add(84, " 物理化学，电化学");
        this.Research.remove(85);
        this.Research.add(85, " 生物医用高分子，天然高分子");
        this.Research.remove(94);
        this.Research.add(94, " 应用化学");
    }

    public void printName() {
        for (int i = 0; i < this.Name.size(); i++) {
            System.out.println(this.Name.get(i));
        }
    }

    public void printEmail() {
        for (int i = 0; i < this.Email.size(); i++) {
            System.out.println(this.Email.get(i));
        }
    }

    public void printResearch() {
        for (int i = 0; i < this.Research.size(); i++) {
            System.out.println(this.Research.get(i));
        }
    }

    public void printTel() {
        for (int i = 0; i < this.Telephone.size(); i++) {
            System.out.println(this.Telephone.get(i));
        }
    }

    public ArrayList<String> getName() {
        return Name;
    }

    public ArrayList<String> getEmail() {
        return Email;
    }

    public ArrayList<String> getTelephone() {
        return Telephone;
    }

    public ArrayList<String> getResearch() {
        return Research;
    }
}
