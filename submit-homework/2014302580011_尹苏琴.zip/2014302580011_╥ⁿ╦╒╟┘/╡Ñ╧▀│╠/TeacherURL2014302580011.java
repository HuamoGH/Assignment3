package com.yinsuqin.homework;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Administrator on 2015/11/8.
 */
public class TeacherURL2014302580011 {
    private Document Index;
    private Elements hrefTag;
    private Object[] URLArray;
    private ArrayList<String> Tag = new ArrayList<>();
    private ArrayList<String> URL = new ArrayList<>();
    private String WebsiteLocation = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=";

    private String RegexForURL = "[<][a][ ]\\w+[=][\"][s][h][o][w][.].+";

    public TeacherURL2014302580011() throws IOException {
        Index = Jsoup.connect("http://staff.whu.edu.cn/").get();
        hrefTag = Index.select("a[href]");
        URLArray = hrefTag.toArray();
        for (int i = 0; i < URLArray.length; i++) {
            if (URLArray[i].toString().matches(RegexForURL)) {
                Tag.add(URLArray[i].toString());
            }
        }

        for (int i = 0;i<Tag.size();i++){
            String[] temp = Tag.get(i).split("\"");
            String[] Name = temp[1].split("=");
            URL.add(i,WebsiteLocation + Name[2]);
        }

        }

    public ArrayList<String> getURL() {
        return URL;
    }
}


